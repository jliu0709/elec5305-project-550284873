function x = simpleISTFT(X, hopSize, winFun)

winLen = length(winFun);
numFrames = size(X,2);

outputLength = (numFrames-1)*hopSize + winLen;

x = zeros(outputLength,1);
windowSum = zeros(outputLength,1);

for i = 1:numFrames

    fullSpectrum = [X(:,i); conj(X(end-1:-1:2,i))];

    frame = real(ifft(fullSpectrum));
    frame = frame .* winFun;

    startIndex = (i-1)*hopSize + 1;
    endIndex = startIndex + winLen - 1;

    x(startIndex:endIndex) = ...
        x(startIndex:endIndex) + frame;

    windowSum(startIndex:endIndex) = ...
        windowSum(startIndex:endIndex) + winFun.^2;
end

valid = windowSum > 1e-6;
x(valid) = x(valid) ./ windowSum(valid);

end